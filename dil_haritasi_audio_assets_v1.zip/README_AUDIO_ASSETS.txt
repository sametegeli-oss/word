Dil Haritası v1 audio ambience asset paketi

Klasör: assets/audio/ambience/
Format: WAV, 22.05kHz, mono, kısa loop taslakları.
GitHub projesine aynı klasör yapısıyla yükleyin.
manifest.json node verisindeki ambienceAudio alanlarıyla eşleştirmek için hazırlandı.

Not: Bunlar telifsiz/sentetik demo ortam sesleridir. İsterseniz ileride gerçek stüdyo/telifsiz MP3 dosyalarıyla değiştirilebilir.
